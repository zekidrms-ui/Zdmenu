# ========================================================
# Kivy Android APK Derleme Scripti (Google Colab için)
# Bu kodları Google Colab hücresine yapıştırıp çalıştırın!
# ========================================================

# 1. Adım: Gerekli Linux paketlerini yükleyin
!sudo apt update -y
!sudo apt install -y git zip unzip autoconf libtool pkg-config zlib1g-dev libncurses5-dev libncursesw5-dev libtinfo5 cmake libffi-dev libssl-dev build-essential
!sudo apt install -y libsqlite3-dev

# 2. Adım: Cython ve Buildozer'ı yükleyin
!pip install --upgrade Cython==0.29.36
!pip install --upgrade buildozer
!pip install --upgrade virtualenv

# 3. Adım: main.py ve buildozer.spec dosyalarınızı hazırlayın
# (Dosyaları sol menüdeki klasör simgesine tıklayarak sürükleyip bırakabilirsiniz)
import os
print("Mevcut dosyalar:", os.listdir('.'))

# 4. Adım: Android Lisanslarını otomatik onaylayarak derlemeyi başlatın
!buildozer android debug

# 5. Adım: Oluşan APK dosyasını doğrudan bilgisayarınıza/telefonunuza indirin
import glob
from google.colab import files

apk_files = glob.glob('bin/*.apk')
if apk_files:
    print("Tebrikler! APK başarıyla oluşturuldu:", apk_files[0])
    files.download(apk_files[0])
else:
    print("Hata: bin klasöründe APK bulunamadı. Lütfen logları inceleyin.")
